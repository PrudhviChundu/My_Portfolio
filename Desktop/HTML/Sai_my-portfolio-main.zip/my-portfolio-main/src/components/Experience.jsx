import { motion } from 'framer-motion'
import { HiCalendar, HiLocationMarker, HiCode, HiLightBulb } from 'react-icons/hi'
import { FaJava, FaReact, FaAngular, FaNodeJs, FaDatabase } from 'react-icons/fa'
import { SiSpringboot, SiMongodb, SiElasticsearch, SiNodedotjs } from 'react-icons/si'
import './Experience.css'

const Experience = () => {
  const timelineEvents = [
    {
      date: 'June 2022',
      company: 'EngageBay',
      location: 'Hyderabad, India',
      title: 'Software Developer - Started Journey',
      type: 'company',
      tech: ['Java', 'Backbone.js'],
      description: 'Began my professional journey at EngageBay',
      achievements: [
        'Developed multiple integrations including Asana, Thinkific, Google Meet, Webex, Typeform, and many more',
        'Worked on Java backend and Backbone.js frontend for EngageBay platform',
        'Implemented various functionalities and UI screens',
        'Gained foundational experience in enterprise application development',
      ],
      icon: <FaJava />,
      color: '#f89820',
    },
    {
      date: 'August 2023',
      company: 'EngageBay - Automations',
      location: 'Hyderabad, India',
      title: 'Automation Development',
      type: 'project',
      tech: ['Java', 'Angular', 'GCP', 'Database'],
      description: 'Enhanced automation capabilities',
      achievements: [
        'Worked on automations for backend in Java',
        'Developed frontend components using Angular',
        'Learned component-based architecture and Angular best practices',
        'Managed database operations on Google Cloud Platform',
      ],
      icon: <FaAngular />,
      color: '#dd0031',
    },
    {
      date: 'August 2023',
      company: 'Falcon',
      location: 'Hyderabad, India',
      title: 'Falcon Platform Development',
      type: 'project',
      tech: ['Java', 'React', 'SOAP'],
      description: 'Built Falcon UI and backend systems',
      achievements: [
        'Developed Falcon UI and backend infrastructure',
        'Implemented Salesforce integration using SOAP requests',
        'Fetched and rendered Salesforce data in Falcon platform',
        'Enhanced data synchronization capabilities',
      ],
      icon: <FaReact />,
      color: '#61dafb',
    },
    {
      date: 'February 2024',
      company: 'Reacho',
      location: 'Hyderabad, India',
      title: 'E-commerce Platform Development',
      type: 'project',
      tech: ['Spring Boot', 'Java', 'React', 'MongoDB'],
      description: 'Built comprehensive e-commerce solution',
      achievements: [
        'Developed Reacho e-commerce platform from EngageBay',
        'Implemented backend using Spring Boot and Java',
        'Built responsive frontend using React',
        'Designed and managed MongoDB database architecture',
      ],
      icon: <SiSpringboot />,
      color: '#6db33f',
    },
    {
      date: 'July 2024',
      company: 'Reacho - React Flow',
      location: 'Hyderabad, India',
      title: 'Flow-Based Application',
      type: 'project',
      tech: ['React', 'React Flow'],
      description: 'Created interactive workflow builder',
      achievements: [
        'Built flow-based application using React Flow library',
        'Designed interactive workflow builder for Reacho platform',
        'Implemented drag-and-drop functionality for workflow creation',
        'Enhanced user experience with visual workflow management',
      ],
      icon: <FaReact />,
      color: '#61dafb',
    },
    {
      date: 'November 2024',
      company: 'EngageBay - Elasticsearch',
      location: 'Hyderabad, India',
      title: 'Elasticsearch Migration',
      type: 'project',
      tech: ['Node.js', 'Elasticsearch', 'MongoDB'],
      description: 'Migrated to Elasticsearch infrastructure',
      achievements: [
        'Learned Elasticsearch database architecture and operations',
        'Migrated all customer data stack to Elasticsearch',
        'Wrote complex queries in Node.js for data operations',
        'Mastered Node.js and asynchronous programming',
        'Optimized search and data retrieval performance',
      ],
      icon: <SiElasticsearch />,
      color: '#005571',
    },
    {
      date: 'January 2025',
      company: 'EngageBay',
      location: 'Hyderabad, India',
      title: 'Customer Support & Team Collaboration',
      type: 'growth',
      tech: ['Java', 'React', 'Angular'],
      description: 'Enhanced team collaboration and problem-solving',
      achievements: [
        'Worked on customer issues and platform enhancements',
        'Helped team members solve individual problems',
        'Developed patience and team management skills',
        'Improved communication and collaboration abilities',
        'Contributed to overall team growth and productivity',
      ],
      icon: <HiLightBulb />,
      color: '#fbbf24',
    },
    {
      date: 'May 2025 - Present',
      company: 'FreshLearn',
      location: 'Hyderabad, India',
      title: 'Software Developer - Microservices',
      type: 'company',
      tech: ['Spring Boot', 'Angular', 'SQL', 'Microservices'],
      description: 'Building scalable microservices architecture',
      achievements: [
        'Working on FreshLearn application improvements',
        'Developing microservice-based architecture using Spring Boot',
        'Building Angular frontend for enhanced user experience',
        'Managing SQL database for data persistence',
        'Working on customer issues and platform enhancements',
        'Continuously learning and implementing new technologies',
      ],
      icon: <SiSpringboot />,
      color: '#6db33f',
    },
  ]

  const getTechIcons = (tech) => {
    const iconMap = {
      'Java': <FaJava />,
      'Spring Boot': <SiSpringboot />,
      'React': <FaReact />,
      'Angular': <FaAngular />,
      'Node.js': <SiNodedotjs />,
      'MongoDB': <SiMongodb />,
      'Elasticsearch': <SiElasticsearch />,
      'SQL': <FaDatabase />,
    }
    return tech.map(t => iconMap[t] || <HiCode />)
  }

  return (
    <section id="experience" className="experience">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="section-header"
        >
          <h2 className="section-title">
            <span className="title-number">02.</span> Professional Journey
          </h2>
          <p className="section-subtitle">
            My career timeline showcasing growth, learning, and contributions
          </p>
        </motion.div>

        <div className="timeline-container">
          <div className="timeline">
            {timelineEvents.map((event, index) => (
              <motion.div
                key={index}
                className={`timeline-item ${event.type}`}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <div className="timeline-marker">
                  <div className="marker-icon" style={{ color: event.color }}>
                    {event.icon}
                  </div>
                  <div className="marker-pulse" style={{ borderColor: event.color }}></div>
                </div>
                <div className="timeline-content">
                  <div className="exp-card">
                    <div className="exp-date-badge">
                      <HiCalendar className="date-icon" />
                      <span>{event.date}</span>
                    </div>
                    <div className="exp-header">
                      <div>
                        <h3 className="exp-title">{event.title}</h3>
                        <h4 className="exp-company">{event.company}</h4>
                        <p className="exp-description">{event.description}</p>
                      </div>
                    </div>
                    <div className="exp-tech-stack">
                      <span className="tech-label">Tech Stack:</span>
                      <div className="tech-icons">
                        {getTechIcons(event.tech).map((icon, idx) => (
                          <span key={idx} className="tech-icon" title={event.tech[idx]}>
                            {icon}
                          </span>
                        ))}
                      </div>
                    </div>
                    <ul className="exp-achievements">
                      {event.achievements.map((achievement, idx) => (
                        <motion.li
                          key={idx}
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.4, delay: index * 0.05 + idx * 0.05 }}
                        >
                          {achievement}
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default Experience
