import { motion } from 'framer-motion'
import './About.css'

const About = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 },
    },
  }

  return (
    <section id="about" className="about">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="section-header"
        >
          <h2 className="section-title">
            <span className="title-number">01.</span> About Me
          </h2>
        </motion.div>

        <motion.div
          className="about-content"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <motion.div className="about-text" variants={itemVariants}>
            <div className="glass-card">
              <h3>Objective</h3>
              <p>
                Software Engineer with experience in building scalable and dynamic applications
                for startups. Proficient in Java, JavaScript, React.js, Angular, Node.js, MongoDB,
                Elasticsearch, and Google Cloud. Passionate about designing robust backend systems
                and interactive frontend applications. Seeking to leverage my skills in full-stack
                development to contribute to innovative projects and drive business growth.
              </p>
            </div>
          </motion.div>

          <motion.div className="about-stats" variants={itemVariants}>
            <div className="stat-card">
              <div className="stat-number">3.5+</div>
              <div className="stat-label">Years Experience</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">10+</div>
              <div className="stat-label">Technologies</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">100%</div>
              <div className="stat-label">Dedication</div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

export default About

